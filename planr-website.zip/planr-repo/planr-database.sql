-- ═══════════════════════════════════════
-- PLANR DATABASE SCHEMA
-- Plak dit in Supabase > SQL Editor > Run
-- ═══════════════════════════════════════

-- Salons (elk bedrijf dat Planr gebruikt)
create table salons (
  id uuid default gen_random_uuid() primary key,
  owner_id uuid references auth.users(id) on delete cascade,
  naam text not null,
  type_bedrijf text not null default 'Kapper',
  email text,
  telefoon text,
  adres text,
  stad text,
  plan text not null default 'free',
  logo_url text,
  created_at timestamptz default now()
);

-- Medewerkers
create table medewerkers (
  id uuid default gen_random_uuid() primary key,
  salon_id uuid references salons(id) on delete cascade,
  naam text not null,
  rol text not null default 'Medewerker',
  email text,
  telefoon text,
  kleur text default '#6bc4ff',
  actief boolean default true,
  created_at timestamptz default now()
);

-- Klanten
create table klanten (
  id uuid default gen_random_uuid() primary key,
  salon_id uuid references salons(id) on delete cascade,
  naam text not null,
  email text,
  telefoon text,
  notities text,
  created_at timestamptz default now()
);

-- Diensten
create table diensten (
  id uuid default gen_random_uuid() primary key,
  salon_id uuid references salons(id) on delete cascade,
  naam text not null,
  beschrijving text,
  prijs numeric(10,2) not null default 0,
  duur_min integer not null default 30,
  categorie text default 'Algemeen',
  actief boolean default true,
  created_at timestamptz default now()
);

-- Afspraken
create table afspraken (
  id uuid default gen_random_uuid() primary key,
  salon_id uuid references salons(id) on delete cascade,
  klant_id uuid references klanten(id) on delete set null,
  medewerker_id uuid references medewerkers(id) on delete set null,
  dienst_id uuid references diensten(id) on delete set null,
  datum_tijd timestamptz not null,
  duur_min integer not null default 30,
  status text not null default 'gepland',
  notities text,
  klant_naam text,
  klant_email text,
  klant_telefoon text,
  created_at timestamptz default now()
);

-- Betalingen
create table betalingen (
  id uuid default gen_random_uuid() primary key,
  salon_id uuid references salons(id) on delete cascade,
  afspraak_id uuid references afspraken(id) on delete set null,
  bedrag numeric(10,2) not null,
  methode text not null default 'pin',
  status text not null default 'betaald',
  datum timestamptz default now()
);

-- ═══════════════════════════════════════
-- ROW LEVEL SECURITY (elke salon ziet alleen eigen data)
-- ═══════════════════════════════════════

alter table salons enable row level security;
alter table medewerkers enable row level security;
alter table klanten enable row level security;
alter table diensten enable row level security;
alter table afspraken enable row level security;
alter table betalingen enable row level security;

-- Salons: eigenaar ziet/bewerkt alleen eigen salon
create policy "Eigen salon" on salons
  for all using (owner_id = auth.uid());

-- Medewerkers: alleen eigen salon
create policy "Eigen medewerkers" on medewerkers
  for all using (
    salon_id in (select id from salons where owner_id = auth.uid())
  );

-- Klanten: alleen eigen salon
create policy "Eigen klanten" on klanten
  for all using (
    salon_id in (select id from salons where owner_id = auth.uid())
  );

-- Diensten: alleen eigen salon
create policy "Eigen diensten" on diensten
  for all using (
    salon_id in (select id from salons where owner_id = auth.uid())
  );

-- Afspraken: eigen salon OF publiek boeken (klant_id is null = online boeking)
create policy "Eigen afspraken" on afspraken
  for all using (
    salon_id in (select id from salons where owner_id = auth.uid())
  );

-- Online boeken: iedereen mag een afspraak aanmaken
create policy "Publiek boeken" on afspraken
  for insert with check (true);

-- Betalingen: alleen eigen salon
create policy "Eigen betalingen" on betalingen
  for all using (
    salon_id in (select id from salons where owner_id = auth.uid())
  );

-- ═══════════════════════════════════════
-- DEMO DATA (optioneel - voor testen)
-- Pas dit aan na je eerste login
-- ═══════════════════════════════════════

-- Voeg dit toe NADAT je bent ingelogd en je salon_id weet:
-- insert into diensten (salon_id, naam, prijs, duur_min, categorie)
-- values
--   ('<jouw-salon-id>', 'Knippen', 35, 45, 'Basis'),
--   ('<jouw-salon-id>', 'Knippen + wassen', 45, 60, 'Basis'),
--   ('<jouw-salon-id>', 'Kleuren', 85, 90, 'Kleur');
