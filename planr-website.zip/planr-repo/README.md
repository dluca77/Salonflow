# Planr — Salon Management App

Een complete salon-beheertool gebouwd met vanilla HTML/CSS/JS en Supabase.

## Pagina's
- `index.html` — Landingspagina
- `login.html` — Inloggen / Registreren
- `dashboard.html` — Agenda (dagweergave)
- `klanten.html` — Klantenbeheer
- `medewerkers.html` — Teamoverzicht
- `diensten.html` — Dienstencatalogus
- `kassa.html` — Kassasysteem
- `rapportages.html` — Omzetcijfers
- `boeken.html` — Online boekingspagina voor klanten

## Setup
1. Maak een Supabase project aan
2. Voer `planr-database.sql` uit in de SQL Editor
3. Voer `planr-extra-policies.sql` uit
4. Credentials staan al ingevuld in `planr.js`

## Online boeken
Stuur klanten naar: `boeken.html?salon=<jouw-salon-uuid>`
