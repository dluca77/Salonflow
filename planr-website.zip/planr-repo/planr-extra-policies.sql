-- ═══════════════════════════════════════════════════════
-- PLANR — EXTRA POLICIES voor publiek boekingssysteem
-- Voer dit uit in Supabase > SQL Editor > Run
-- (aanvullend op planr-database.sql)
-- ═══════════════════════════════════════════════════════

-- Diensten: publiek leesbaar (voor boeken.html)
create policy "Publiek diensten lezen" on diensten
  for select using (true);

-- Medewerkers: publiek leesbaar (voor boeken.html)
create policy "Publiek medewerkers lezen" on medewerkers
  for select using (true);

-- Salons: publiek leesbaar (voor salonnaam in header)
create policy "Publiek salons lezen" on salons
  for select using (true);
